def int2enumtRA0(tRA):
    #return str(tRA)
    prefix="lte::enums::prachOccasionTDDFrameRepMode::"
    prefix=""
    if tRA == 0:
        return prefix+"any"
    if tRA == 1:
        return prefix+"even"
    if tRA == 2:
        return prefix+"odd"
    assert 0


def int2enumtRA1(tRA):
    #return str(tRA)
    prefix="lte::enums::prachOccasionTDDNhf::"
    prefix=""
    if tRA == 0:
        return prefix+"nHf0"
    if tRA == 1:
        return prefix+"nHf1"
    assert 0
        


fHandle = open("book2.txt", "r");

lineCnt = 0;

configs = [[[] for tddConfigs in range(0, 7)] for columns in range(0, 64)];

#print(len(configs))
#print(len(configs[0][0]))

for line in fHandle:
    lineCnt = lineCnt + 1
    words = line.split(",")
    assert 8 == len(words)
    prachConfigIdxList = words[0].split("/")
    #print(len(prachConfigIdxList))
    for prachCfgStr in prachConfigIdxList:
        prachCfgIdx = int(prachCfgStr.strip())
        for tddCfg in range(0, 7):
            tpl = words[1 + tddCfg].strip()
            if tpl == "N/A":
                naTuple = (255, 255, 255, 255)
                configs[prachCfgIdx][tddCfg].append(naTuple)
            else:
                if 9 != len(tpl):
                    print(tpl, prachCfgIdx, tddCfg)
                    assert 0
                else:
                    tpl = tpl[1:]
                    tpl = tpl[:-1]
                    tplElems = tpl.split(" ")
                    assert 4 == len(tplElems)
                    if(tplElems[3] == "*"):
                        tplElems[3] = "255"
                    anTuple = (int(tplElems[0]), int(tplElems[1]), int(tplElems[2]), int(tplElems[3]))
                    configs[prachCfgIdx][tddCfg].append(anTuple)


    assert prachCfgIdx >= 0
    assert prachCfgIdx < 64

fHandle.close()

fHandle = open("table.txt", "w")

for prachCfgIdx in range(0, 64):
    line = "{" + str(prachCfgIdx) + ", {{"
    for tddCfgs in range(0, 7):
        line = line + "{"
        tuples = configs[prachCfgIdx][tddCfgs]
        numTuples = len(tuples)
        assert(0 < numTuples)
        assert(7 > numTuples)
        naTuple = (255, 255, 255, 255)
        isNa = 0;
        if tuples[0] == naTuple:
            isNa = 1
        if isNa:
            line = line + "},"
        else:
            for tpl in tuples:
                if tpl == naTuple:
                    assert 0
                assert 4 == len(tpl)
                line = line + "{" + str(tpl[0]) + "," + int2enumtRA0(tpl[1]) + "," + int2enumtRA1(tpl[2]) + ","
                if tpl[3] == 255:
                    line = line + "sfDontCare},"
                else:
                    line = line + str(tpl[3]) + "},"
            line = line[:-1]
            line = line + "},"
    line = line[:-1]
    line = line + "}}},\n"
    fHandle.write(line)

fHandle.close()


